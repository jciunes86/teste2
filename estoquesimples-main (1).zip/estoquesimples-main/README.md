# estoquesimples
Estoque Simples é um aplicativo criado para facilitar o processo de cadastramento de produtos. Através da leitura do codigo de barras de um produto, os dados presentes no cadastro nacional de produtos (GTIN) serão trazidos e automaticamente preenchidos agilizando o processo de cadastramento de itens de estoque.
